<template>
	<div>
		<detail-banner></detail-banner>
	</div>
</template>

<script>
	import DetailBanner from './components/Banner'
	export default {
		data() {
			return {
				
			};
		},
		components:{
			DetailBanner
		}
	}
</script>

<style lang="stylus" scoped="scoped">

</style>
